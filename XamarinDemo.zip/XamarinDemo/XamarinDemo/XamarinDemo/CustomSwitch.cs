﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace XamarinDemo
{
    public class CustomSwitch : Switch
    {
        public CustomSwitch()
        {

        }
    }
}

﻿using System;

namespace UsingDependencyService
{
	public interface ITextToSpeech
	{
		void Speak (string text);
	}
}


Xamarin.Forms DependencyService
==============

Sample code for the [Xamarin.Forms DependencyService](http://developer.xamarin.com/guides/cross-platform/xamarin-forms/dependency-service/) doc.

The sample shows how to implement **text to speech** on iOS, Android and the Universal Windows Platform using Xamarin.Forms but calling out to the native platform SDKs for speech.

Author
------

Craig Dunn
